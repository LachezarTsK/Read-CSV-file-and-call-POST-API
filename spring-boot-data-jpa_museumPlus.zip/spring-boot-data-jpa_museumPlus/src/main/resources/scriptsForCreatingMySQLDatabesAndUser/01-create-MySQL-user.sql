-- Drop user first if they exist
DROP USER if exists 'lachezar'@'%' ;

-- Now create user with prop privileges
CREATE USER 'lachezar'@'%' IDENTIFIED BY 'lachezar';

GRANT ALL PRIVILEGES ON * . * TO 'lachezar'@'%';